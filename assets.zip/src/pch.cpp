#include "pch.h"

#define STB_IMAGE_IMPLEMENTATION
#include "utilities/stb_image.h"